#!/usr/bin/env python
from resource_management import *

# config object that holds the configurations declared in the -config.xml file
config = Script.get_config()

# tachyon underfs address
underfs_addr = config['configurations']['tachyon-env']['tachyon.underfs_address']

# tachyon worker memory alotment 
worker_mem = config['configurations']['tachyon-env']['tachyon.worker_memory']
